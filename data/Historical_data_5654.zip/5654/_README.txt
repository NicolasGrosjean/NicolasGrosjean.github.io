Data from ohsome[1] with the tool Missing Maps OSM data exporter[2].

You can follow this tutorial[3] to use these data with QGIS

1 : http://api.ohsome.org/v0.9/swagger-ui.html
2 : https://github.com/NicolasGrosjean/Missing_Maps_OSM_data_exporter
3 : https://github.com/NicolasGrosjean/Missing_Maps_OSM_data_exporter/wiki/Use-historical-OSM-data-of-a-Missing-Maps-project-in-QGIS
